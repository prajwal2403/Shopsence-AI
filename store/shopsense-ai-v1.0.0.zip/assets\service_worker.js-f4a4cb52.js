import { M as MSG, b as buildMsg } from "./messaging-f5f63792.js";
import { c as clearCached, a as clearAllCache, g as getCached, s as setCached } from "./cache-62d667f2.js";
const API_BASE = "http://localhost:8000";
let popupPort = null;
chrome.runtime.onConnect.addListener((port) => {
  if (port.name === "popup") {
    popupPort = port;
    port.onDisconnect.addListener(() => {
      popupPort = null;
    });
  }
});
function postToPopup(type, payload = {}) {
  if (popupPort) {
    popupPort.postMessage(buildMsg(type, payload));
  }
}
chrome.runtime.onInstalled.addListener(async () => {
  console.log("[ShopSense] Extension installed.");
  await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const { type, payload } = message;
  switch (type) {
    case MSG.SCRAPE_RESULT: {
      handleScrapeResult(payload);
      sendResponse({ ok: true });
      break;
    }
    case MSG.NOT_PRODUCT_PAGE: {
      postToPopup(MSG.NOT_PRODUCT_PAGE, {});
      sendResponse({ ok: true });
      break;
    }
    case MSG.REQUEST_ANALYSIS: {
      requestAnalysis(payload.tabId, payload.url, payload.forceRefresh).then(() => sendResponse({ ok: true })).catch((err) => sendResponse({ ok: false, error: err.message }));
      return true;
    }
    case MSG.CLEAR_CACHE: {
      const target = payload.url ? clearCached(payload.url) : clearAllCache();
      target.then(() => sendResponse({ ok: true }));
      return true;
    }
  }
});
async function handleScrapeResult(productData) {
  const { url } = productData;
  const cached = await getCached(url);
  if (cached) {
    console.log("[ShopSense] Cache hit for", url);
    postToPopup(MSG.CACHE_HIT, cached);
    return;
  }
  await callAnalysisApi(productData);
}
async function requestAnalysis(tabId, url, forceRefresh = false) {
  if (!forceRefresh) {
    const cached = await getCached(url);
    if (cached) {
      postToPopup(MSG.CACHE_HIT, cached);
      return;
    }
  } else {
    await clearCached(url);
  }
  postToPopup(MSG.STATUS_UPDATE, { status: "scraping", message: "Reading product page…" });
  try {
    await chrome.tabs.sendMessage(tabId, buildMsg(MSG.INIT_SCRAPER));
  } catch {
    postToPopup(MSG.ANALYSIS_ERROR, {
      message: "Could not read this page. Make sure you are on a supported product page."
    });
  }
}
async function callAnalysisApi(productData) {
  postToPopup(MSG.STATUS_UPDATE, { status: "analyzing", message: "AI is analysing the product…" });
  try {
    const response = await fetch(`${API_BASE}/api/analyze`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Extension-Id": chrome.runtime.id
        // used by backend for rate limiting
      },
      body: JSON.stringify(productData)
    });
    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(err.detail || `Server error ${response.status}`);
    }
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    let finalResult = null;
    while (true) {
      const { done, value } = await reader.read();
      if (done)
        break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop();
      for (const line of lines) {
        if (!line.startsWith("data: "))
          continue;
        const jsonStr = line.slice(6).trim();
        if (jsonStr === "[DONE]")
          break;
        try {
          const chunk = JSON.parse(jsonStr);
          if (chunk.type === "progress") {
            postToPopup(MSG.ANALYSIS_PROGRESS, chunk);
          } else if (chunk.type === "result") {
            finalResult = chunk.data;
          } else if (chunk.type === "cache_hit") {
            finalResult = chunk.data;
          }
        } catch {
        }
      }
    }
    if (finalResult) {
      await setCached(productData.url, finalResult);
      postToPopup(MSG.ANALYSIS_COMPLETE, finalResult);
    } else {
      throw new Error("No result received from server.");
    }
  } catch (err) {
    console.error("[ShopSense] API error:", err);
    postToPopup(MSG.ANALYSIS_ERROR, { message: err.message });
  }
}
//# sourceMappingURL=service_worker.js-f4a4cb52.js.map
