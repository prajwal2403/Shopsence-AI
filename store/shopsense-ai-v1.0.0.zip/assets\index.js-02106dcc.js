import { M as MSG, b as buildMsg } from "./messaging-f5f63792.js";
const scriptRel = "modulepreload";
const assetsURL = function(dep) {
  return "/" + dep;
};
const seen = {};
const __vitePreload = function preload(baseModule, deps, importerUrl) {
  if (!deps || deps.length === 0) {
    return baseModule();
  }
  const links = document.getElementsByTagName("link");
  return Promise.all(deps.map((dep) => {
    dep = assetsURL(dep);
    if (dep in seen)
      return;
    seen[dep] = true;
    const isCss = dep.endsWith(".css");
    const cssSelector = isCss ? '[rel="stylesheet"]' : "";
    const isBaseRelative = !!importerUrl;
    if (isBaseRelative) {
      for (let i = links.length - 1; i >= 0; i--) {
        const link2 = links[i];
        if (link2.href === dep && (!isCss || link2.rel === "stylesheet")) {
          return;
        }
      }
    } else if (document.querySelector(`link[href="${dep}"]${cssSelector}`)) {
      return;
    }
    const link = document.createElement("link");
    link.rel = isCss ? "stylesheet" : scriptRel;
    if (!isCss) {
      link.as = "script";
      link.crossOrigin = "";
    }
    link.href = dep;
    document.head.appendChild(link);
    if (isCss) {
      return new Promise((res, rej) => {
        link.addEventListener("load", res);
        link.addEventListener("error", () => rej(new Error(`Unable to preload CSS for ${dep}`)));
      });
    }
  })).then(() => baseModule()).catch((err) => {
    const e = new Event("vite:preloadError", { cancelable: true });
    e.payload = err;
    window.dispatchEvent(e);
    if (!e.defaultPrevented) {
      throw err;
    }
  });
};
const bundledRegistry = {
  "amazon.in": {
    productName: "#productTitle",
    priceWhole: ".a-price-whole",
    priceFraction: ".a-price-fraction",
    priceFallback: "#priceblock_ourprice, #priceblock_dealprice, .apexPriceToPay .a-offscreen",
    rating: "#acrPopover .a-icon-alt, #averageCustomerReviews .a-icon-alt",
    reviewCount: "#acrCustomerReviewText",
    availability: "#availability span, #outOfStock",
    deliveryDate: "#mir-layout-DELIVERY_BLOCK .a-text-bold, #deliveryBlockMessage .a-text-bold",
    sellerName: "#sellerProfileTriggerId, #merchant-info a",
    returnPolicy: "#productDetails_db_sections .a-expander-content",
    imageUrl: "#landingImage, #imgTagWrapperId img",
    bulletPoints: "#feature-bullets li .a-list-item",
    techSpecTable: "#productDetails_techSpec_section_1 tr, #productDetails_techSpec_section_2 tr",
    detailBullets: "#detailBullets_feature_div li span.a-list-item",
    reviewItems: "[data-hook='review']",
    reviewAuthor: "span.a-profile-name",
    reviewRating: "[data-hook='review-star-rating'] .a-icon-alt, [data-hook='cmps-review-star-rating'] .a-icon-alt",
    reviewTitle: "[data-hook='review-title'] span:not(.a-letter-space)",
    reviewBody: "[data-hook='review-body'] span",
    reviewDate: "[data-hook='review-date']",
    reviewVerified: "[data-hook='avp-badge']"
  },
  "amazon.com": {
    productName: "#productTitle",
    priceWhole: ".a-price-whole",
    priceFraction: ".a-price-fraction",
    priceFallback: "#priceblock_ourprice, .apexPriceToPay .a-offscreen",
    rating: "#acrPopover .a-icon-alt",
    reviewCount: "#acrCustomerReviewText",
    availability: "#availability span",
    deliveryDate: "#mir-layout-DELIVERY_BLOCK .a-text-bold",
    sellerName: "#sellerProfileTriggerId",
    imageUrl: "#landingImage",
    bulletPoints: "#feature-bullets li .a-list-item",
    techSpecTable: "#productDetails_techSpec_section_1 tr",
    detailBullets: "#detailBullets_feature_div li span.a-list-item",
    reviewItems: "[data-hook='review']",
    reviewAuthor: "span.a-profile-name",
    reviewRating: "[data-hook='review-star-rating'] .a-icon-alt",
    reviewTitle: "[data-hook='review-title'] span:not(.a-letter-space)",
    reviewBody: "[data-hook='review-body'] span",
    reviewDate: "[data-hook='review-date']",
    reviewVerified: "[data-hook='avp-badge']"
  },
  "flipkart.com": {
    productName: "span.VU-ZEz, h1._6EBuvT, .B_NuCI, h1.yhB1nd",
    price: "._1vC4OE._3qQ9m1, ._30jeq3._16Jk6d, ._30jeq3",
    mrp: "._3I9_wc._2p6lqe, ._3I9_wc",
    rating: "._3LWZlK, div.XQDdHH",
    reviewCount: "span._2_R_DZ span, span._2_R_DZ",
    availability: "._1dVbu9 ._2Sil6l",
    deliveryDate: "._2_R_DZ._3nEd4j, ._3XINGv",
    sellerName: ".WS7BWe a, #sellerName a",
    imageUrl: "img._396cs4._2amPTt._3qGmMb, img._396cs4, ._2r_T1I img",
    specTable: "._14cfVK tr, ._3k-BhJ tr",
    reviewItems: "._1AtVbE.col._2wzgFH, ._1AtVbE .t-ZTKy",
    reviewAuthor: "._2sc7ZR p._2NsDsR",
    reviewRating: "._3LWZlK",
    reviewTitle: "._2-N8zT",
    reviewBody: ".t-ZTKy .qwjRop",
    reviewDate: "._2sc7ZR p:last-child",
    reviewVerified: "._23Hw8w"
  },
  "myntra.com": {
    productName: "h1.pdp-name, h1.pdp-title",
    brand: "h1.pdp-name span, .pdp-name span:first-child",
    price: ".pdp-price strong, span.pdp-mrp strong",
    mrp: "span.pdp-mrp s",
    rating: ".index-overallRating div, .detailed-rating div",
    reviewCount: "a.index-ratingsCount",
    imageUrl: ".image-grid-imageContainer img, .pdp-image img",
    specTable: ".index-tableContainer tr, .product-desc-table-row",
    sellerName: ".supplier-section .supply-section-row-value",
    reviewItems: ".user-review-main",
    reviewAuthor: ".user-review-author",
    reviewRating: ".user-review-rating span",
    reviewTitle: ".user-review-title",
    reviewBody: ".user-review-body",
    reviewDate: ".user-review-date",
    reviewVerified: ".user-review-verified"
  },
  "meesho.com": {
    productName: "p.NewProductDescription__ProductName, span.NewProductDescription__ProductName, h1",
    price: "h4.NewProductDescription__BoldText, h4",
    mrp: "p.NewProductDescription__strikethrough",
    rating: "p.NewProductDescription__Rating",
    reviewCount: "p.NewProductDescription__ReviewCount",
    imageUrl: "img.HeroImage__HeroImageContainer",
    specTable: "table.ProductDescription__table tr",
    reviewItems: ".ProductReviews__Card",
    reviewAuthor: ".ProductReviews__userName",
    reviewRating: ".ProductReviews__rating",
    reviewBody: ".ProductReviews__comment"
  },
  "nykaa.com": {
    productName: "h1.css-1gc4x7i, h1[class*='ProductTitle']",
    price: "span.css-111z9ua, span[class*='price']",
    mrp: "span.css-5hcpkk",
    rating: "div.css-1420u3b span, span[class*='rating']",
    reviewCount: "span.css-zkfxvx",
    imageUrl: "img.css-qjh4ps, img[class*='product']",
    specTable: "div[class*='keyIngredients'] li, div[class*='productDesc'] li",
    reviewItems: "div[class*='reviewCard'], div.css-1s2f8q9",
    reviewAuthor: "p[class*='reviewerName'], p.css-y6b7tb",
    reviewRating: "span[class*='reviewRating']",
    reviewBody: "p[class*='reviewText'], p.css-1ugefth",
    reviewDate: "span[class*='reviewDate']"
  },
  "snapdeal.com": {
    productName: "h1.pdp-e-i-head",
    price: "span.payBlkBig",
    mrp: "span.pdpCutPrice",
    rating: "strong.product-rating",
    reviewCount: "span.product-reviews-count",
    imageUrl: "div.cloudzoom-container img, #product-image img",
    specTable: "table.product-spec tr",
    reviewItems: "div.user-review",
    reviewAuthor: "span.reviewer",
    reviewRating: "span.filled-stars",
    reviewBody: "p.user-review-body",
    reviewDate: "span.review-date",
    reviewVerified: "span.purchase-verified"
  }
};
const REMOTE_REGISTRY_URL = "https://raw.githubusercontent.com/prajwal2403/Shopsence-AI/main/extension/src/content/scrapers/registry.json";
const REGISTRY_CACHE_KEY = "shopsense_registry";
const REGISTRY_TTL_MS = 6 * 60 * 60 * 1e3;
const PLATFORM_RULES = [
  {
    platform: "amazon",
    hostname: /amazon\.(in|com)$/,
    registryKey: (host) => host.includes("amazon.in") ? "amazon.in" : "amazon.com",
    isProduct: () => /\/dp\/[A-Z0-9]{10}/.test(location.pathname) || /\/gp\/product\/[A-Z0-9]{10}/.test(location.pathname),
    scraper: () => __vitePreload(() => import("./amazon-edc72b7d.js"), true ? ["assets/amazon-edc72b7d.js","assets/utils-369fade9.js"] : void 0)
  },
  {
    platform: "flipkart",
    hostname: /flipkart\.com$/,
    registryKey: () => "flipkart.com",
    isProduct: () => location.pathname.startsWith("/p/") || !!document.querySelector('[class*="pdp"], [class*="product-page"]'),
    scraper: () => __vitePreload(() => import("./flipkart-b0063fa2.js"), true ? ["assets/flipkart-b0063fa2.js","assets/utils-369fade9.js"] : void 0)
  },
  {
    platform: "myntra",
    hostname: /myntra\.com$/,
    registryKey: () => "myntra.com",
    isProduct: () => /\/[a-z-]+\/p\/\d+/.test(location.pathname),
    scraper: () => __vitePreload(() => import("./myntra-95185dee.js"), true ? ["assets/myntra-95185dee.js","assets/utils-369fade9.js"] : void 0)
  },
  {
    platform: "meesho",
    hostname: /meesho\.com$/,
    registryKey: () => "meesho.com",
    isProduct: () => location.pathname.includes("/product/"),
    scraper: null
    // Phase 3 — uses generic fallback below
  },
  {
    platform: "nykaa",
    hostname: /nykaa\.com$/,
    registryKey: () => "nykaa.com",
    isProduct: () => location.pathname.includes("/p/") || location.pathname.includes("/buy/"),
    scraper: null
  },
  {
    platform: "snapdeal",
    hostname: /snapdeal\.com$/,
    registryKey: () => "snapdeal.com",
    isProduct: () => location.pathname.startsWith("/product/"),
    scraper: null
  }
];
async function loadRegistry() {
  try {
    const stored = await chrome.storage.local.get(REGISTRY_CACHE_KEY);
    const entry = stored[REGISTRY_CACHE_KEY];
    if (entry && Date.now() - entry.cachedAt < REGISTRY_TTL_MS) {
      refreshRegistryInBackground();
      return entry.data;
    }
  } catch {
  }
  refreshRegistryInBackground();
  return bundledRegistry;
}
function refreshRegistryInBackground() {
  fetch(REMOTE_REGISTRY_URL, { cache: "no-cache" }).then((r) => r.json()).then((data) => {
    chrome.storage.local.set({
      [REGISTRY_CACHE_KEY]: { data, cachedAt: Date.now() }
    });
  }).catch(() => {
  });
}
function genericScrape(platform, sel) {
  var _a;
  const { $, $all, text, cleanPrice, extractStars, safeInt, parseStockStatus, extractReviews, extractTableSpecs } = (
    // Inline minimal helpers for generic fallback
    (() => {
      const q2 = (s) => {
        try {
          return document.querySelector(s);
        } catch {
          return null;
        }
      };
      const qa = (s) => {
        try {
          return Array.from(document.querySelectorAll(s));
        } catch {
          return [];
        }
      };
      return {
        $: q2,
        $all: qa,
        text: (s) => {
          var _a2, _b;
          return ((_b = (_a2 = q2(s)) == null ? void 0 : _a2.textContent) == null ? void 0 : _b.trim()) || "";
        },
        cleanPrice: (r) => {
          const n = parseFloat((r || "").replace(/[^0-9.]/g, ""));
          return isNaN(n) ? null : n;
        },
        extractStars: (r) => {
          const m = (r || "").match(/(\d+\.?\d*)/);
          const n = parseFloat(m == null ? void 0 : m[1]);
          return isNaN(n) ? null : Math.min(n, 5);
        },
        safeInt: (r) => {
          const n = parseInt((r || "").replace(/[^0-9]/g, ""), 10);
          return isNaN(n) ? null : n;
        },
        parseStockStatus: () => "unknown",
        extractReviews: () => [],
        extractTableSpecs: () => ({})
      };
    })()
  );
  return {
    platform,
    url: location.href,
    productName: text(sel == null ? void 0 : sel.productName) || document.title.split("|")[0].trim(),
    price: cleanPrice(text(sel == null ? void 0 : sel.price)),
    currency: "INR",
    rating: extractStars(text(sel == null ? void 0 : sel.rating)),
    reviewCount: safeInt(text(sel == null ? void 0 : sel.reviewCount)),
    topReviews: [],
    specs: {},
    sellerName: "",
    returnPolicy: "",
    deliveryEstimate: "",
    stockStatus: "unknown",
    imageUrl: ((_a = q(sel == null ? void 0 : sel.imageUrl)) == null ? void 0 : _a.src) || ""
  };
}
async function scrapeAndSend() {
  const host = location.hostname;
  const rule = PLATFORM_RULES.find((r) => r.hostname.test(host));
  if (!rule)
    return;
  if (!rule.isProduct()) {
    chrome.runtime.sendMessage(buildMsg(MSG.NOT_PRODUCT_PAGE));
    return;
  }
  const registry = await loadRegistry();
  const regKey = rule.registryKey(host);
  const sel = registry[regKey] || {};
  let productData;
  if (rule.scraper) {
    try {
      const mod = await rule.scraper();
      productData = mod.scrape(sel);
    } catch (e) {
      console.warn("[ShopSense] Scraper error, falling back to generic:", e);
      productData = genericScrape(rule.platform, sel);
    }
  } else {
    productData = genericScrape(rule.platform, sel);
  }
  console.group("%c[ShopSense AI] Scraped ProductData", "color:#6366F1;font-weight:bold");
  console.log("Platform  :", productData.platform);
  console.log("Name      :", productData.productName);
  console.log("Price     :", productData.price, productData.currency);
  console.log("Rating    :", productData.rating, "/ 5");
  console.log("Reviews   :", productData.reviewCount);
  console.log("Stock     :", productData.stockStatus);
  console.log("Delivery  :", productData.deliveryEstimate);
  console.log("Seller    :", productData.sellerName);
  console.log("Specs     :", productData.specs);
  console.log("Top Reviews:", productData.topReviews);
  console.log("Full object:", productData);
  console.groupEnd();
  chrome.runtime.sendMessage(buildMsg(MSG.SCRAPE_RESULT, productData));
}
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === MSG.INIT_SCRAPER) {
    scrapeAndSend().then(() => sendResponse({ ok: true }));
    return true;
  }
});
scrapeAndSend();
//# sourceMappingURL=index.js-02106dcc.js.map
