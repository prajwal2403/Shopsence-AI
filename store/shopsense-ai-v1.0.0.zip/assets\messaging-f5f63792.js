const MSG = {
  // Content → Background
  SCRAPE_RESULT: "SCRAPE_RESULT",
  NOT_PRODUCT_PAGE: "NOT_PRODUCT_PAGE",
  // Background → Content
  INIT_SCRAPER: "INIT_SCRAPER",
  // Popup → Background
  REQUEST_ANALYSIS: "REQUEST_ANALYSIS",
  CLEAR_CACHE: "CLEAR_CACHE",
  // Background → Popup (via port)
  ANALYSIS_PROGRESS: "ANALYSIS_PROGRESS",
  ANALYSIS_COMPLETE: "ANALYSIS_COMPLETE",
  ANALYSIS_ERROR: "ANALYSIS_ERROR",
  CACHE_HIT: "CACHE_HIT",
  STATUS_UPDATE: "STATUS_UPDATE"
};
const PORTS = {
  POPUP: "popup"
};
function sendToBackground(type, payload = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ type, payload }, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve(response);
      }
    });
  });
}
function connectToBackground(name = PORTS.POPUP) {
  return chrome.runtime.connect({ name });
}
function buildMsg(type, payload = {}) {
  return { type, payload, timestamp: Date.now() };
}
export {
  MSG as M,
  buildMsg as b,
  connectToBackground as c,
  sendToBackground as s
};
//# sourceMappingURL=messaging-f5f63792.js.map
