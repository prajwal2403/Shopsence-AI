import { t as text, c as cleanPrice, $ as $all, e as extractStars, s as safeInt, p as parseStockStatus, a as $, b as extractTableSpecs, f as extractReviews } from "./utils-369fade9.js";
function scrape(sel) {
  var _a, _b;
  const productName = text(sel.productName) || ((_b = (_a = document.querySelector("h1")) == null ? void 0 : _a.textContent) == null ? void 0 : _b.trim()) || document.title.split("|")[0].trim();
  let price = cleanPrice(text(sel.price));
  if (!price) {
    const candidates = $all("span, div, p");
    for (const el of candidates) {
      if (el.children.length === 0 && el.textContent.includes("₹")) {
        const v = cleanPrice(el.textContent);
        if (v && v > 0) {
          price = v;
          break;
        }
      }
    }
  }
  const mrp = cleanPrice(text(sel.mrp));
  let rating = extractStars(text(sel.rating));
  if (!rating) {
    const ratingRaw = text(sel.rating);
    const n = parseFloat(ratingRaw);
    if (!isNaN(n) && n >= 0 && n <= 5)
      rating = n;
  }
  const reviewCount = safeInt(text(sel.reviewCount));
  const addToCartBtn = document.querySelector("button._2KpZ6l._2U9uOA._3v1-ww") || document.querySelector('[class*="add-to-cart"]') || document.querySelector('button[class*="AddToCart"]');
  const outOfStockEl = document.querySelector('[class*="outOfStock"], ._16FRp0');
  const stockStatus = outOfStockEl ? "out_of_stock" : addToCartBtn ? "in_stock" : parseStockStatus(text(sel.availability));
  const deliveryEstimate = text(sel.deliveryDate);
  const sellerName = text(sel.sellerName);
  const imgEl = $(sel.imageUrl);
  const imageUrl = (imgEl == null ? void 0 : imgEl.src) || (imgEl == null ? void 0 : imgEl.getAttribute("src")) || "";
  const specs = extractTableSpecs(sel.specTable);
  if (Object.keys(specs).length < 2) {
    document.querySelectorAll("table tr").forEach((row) => {
      const cells = row.querySelectorAll("td");
      if (cells.length >= 2) {
        const k = cells[0].textContent.trim();
        const v = cells[1].textContent.trim();
        if (k && v && k.length < 80)
          specs[k] = v.slice(0, 200);
      }
    });
  }
  const topReviews = extractReviews(sel, 10);
  return {
    platform: "flipkart",
    url: location.href,
    productName,
    price,
    currency: "INR",
    rating,
    reviewCount,
    topReviews,
    specs,
    sellerName,
    returnPolicy: "",
    // Flipkart shows this in a modal — not accessible via static DOM
    deliveryEstimate,
    stockStatus,
    imageUrl,
    // Extra Flipkart-specific fields passed for context
    _mrp: mrp
  };
}
export {
  scrape
};
//# sourceMappingURL=flipkart-b0063fa2.js.map
