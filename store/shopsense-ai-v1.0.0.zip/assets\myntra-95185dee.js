import { a as $, c as cleanPrice, t as text, s as safeInt, $ as $all, p as parseStockStatus, b as extractTableSpecs, f as extractReviews } from "./utils-369fade9.js";
function scrape(sel) {
  var _a, _b;
  const nameEl = $(sel.productName);
  const productName = ((_a = nameEl == null ? void 0 : nameEl.textContent) == null ? void 0 : _a.trim()) || document.title.split("|")[0].trim();
  let price = cleanPrice(text(sel.price));
  if (!price) {
    const metaPrice = document.querySelector('meta[property="product:price:amount"]');
    price = cleanPrice(metaPrice == null ? void 0 : metaPrice.content);
  }
  const mrp = cleanPrice(text(sel.mrp));
  let rating = null;
  const ratingText = text(sel.rating);
  const ratingNum = parseFloat(((_b = ratingText.match(/(\d+\.?\d*)/)) == null ? void 0 : _b[1]) || "");
  if (!isNaN(ratingNum) && ratingNum > 0)
    rating = Math.min(ratingNum, 5);
  const reviewCount = safeInt(text(sel.reviewCount));
  const sizesBtns = $all(".size-buttons-size-button, .sizeSelectorDesktop__sizeBtn");
  const hasAvailableSize = sizesBtns.some(
    (btn) => !btn.classList.toString().toLowerCase().includes("out") && !btn.classList.toString().toLowerCase().includes("disabled")
  );
  const stockStatus = sizesBtns.length === 0 ? parseStockStatus(text(sel.availability)) : hasAvailableSize ? "in_stock" : "out_of_stock";
  const sellerName = text(sel.sellerName);
  const imgEl = $(sel.imageUrl);
  const imageUrl = (imgEl == null ? void 0 : imgEl.src) || (imgEl == null ? void 0 : imgEl.getAttribute("data-src")) || "";
  const specs = extractTableSpecs(sel.specTable);
  $all(".pdp-product-description-content li, .pdp-description-item").forEach((el, i) => {
    const val = el.textContent.trim().replace(/\s+/g, " ");
    if (val && val.length < 300)
      specs[`Detail ${i + 1}`] = val;
  });
  const deliveryEstimate = text("._2ZKZf") || "";
  const topReviews = extractReviews(sel, 10);
  const returnPolicy = text(".return-period, .pdp-returns-exchange") || text('[class*="returnPeriod"]');
  return {
    platform: "myntra",
    url: location.href,
    productName,
    price,
    currency: "INR",
    rating,
    reviewCount,
    topReviews,
    specs,
    sellerName,
    returnPolicy,
    deliveryEstimate,
    stockStatus,
    imageUrl,
    _mrp: mrp
  };
}
export {
  scrape
};
//# sourceMappingURL=myntra-95185dee.js.map
