const $ = (selector, root = document) => {
  if (!selector)
    return null;
  const parts = selector.split(" || ");
  for (const part of parts) {
    try {
      const el = root.querySelector(part.trim());
      if (el)
        return el;
    } catch {
    }
  }
  return null;
};
const $all = (selector, root = document) => {
  if (!selector)
    return [];
  const parts = selector.split(" || ");
  for (const part of parts) {
    try {
      const els = Array.from(root.querySelectorAll(part.trim()));
      if (els.length > 0)
        return els;
    } catch {
    }
  }
  return [];
};
const text = (selector, root = document) => {
  var _a, _b;
  return ((_b = (_a = $(selector, root)) == null ? void 0 : _a.textContent) == null ? void 0 : _b.trim()) || "";
};
function cleanPrice(raw) {
  if (!raw)
    return null;
  const digits = raw.replace(/[^0-9.]/g, "");
  const n = parseFloat(digits);
  return isNaN(n) ? null : n;
}
function extractStars(raw) {
  if (!raw)
    return null;
  const match = raw.match(/(\d+[.,]\d+|\d+)\s*(?:out of|\/)?/i);
  if (!match)
    return null;
  const n = parseFloat(match[1].replace(",", "."));
  return isNaN(n) ? null : Math.min(n, 5);
}
function safeInt(raw) {
  if (!raw)
    return null;
  const digits = raw.replace(/[^0-9]/g, "");
  const n = parseInt(digits, 10);
  return isNaN(n) ? null : n;
}
function parseStockStatus(raw = "") {
  const s = raw.toLowerCase();
  if (s.includes("out of stock") || s.includes("unavailable") || s.includes("sold out"))
    return "out_of_stock";
  if (s.includes("only") || s.includes("hurry") || s.includes("few left") || s.includes("limited"))
    return "limited";
  if (s.includes("in stock") || s.includes("available") || s.includes("add to cart"))
    return "in_stock";
  return "unknown";
}
function extractReview(el, sel) {
  var _a;
  const body = text(sel.reviewBody, el) || text((_a = sel.reviewBody) == null ? void 0 : _a.split(",")[0], el);
  if (!body)
    return null;
  return {
    author: text(sel.reviewAuthor, el),
    rating: extractStars(text(sel.reviewRating, el)),
    title: text(sel.reviewTitle, el),
    body,
    verified: !!$(sel.reviewVerified, el),
    date: text(sel.reviewDate, el)
  };
}
function extractReviews(sel, limit = 10) {
  return $all(sel.reviewItems).slice(0, limit).map((el) => extractReview(el, sel)).filter(Boolean);
}
function extractTableSpecs(tableSelector) {
  const specs = {};
  $all(tableSelector).forEach((row) => {
    const cells = row.querySelectorAll("td, th");
    if (cells.length >= 2) {
      const k = cells[0].textContent.trim().replace(/\s+/g, " ");
      const v = cells[1].textContent.trim().replace(/\s+/g, " ");
      if (k && v && k.length < 80)
        specs[k] = v;
    }
  });
  return specs;
}
function extractBulletSpecs(bulletSelector) {
  const specs = {};
  $all(bulletSelector).forEach((el) => {
    const t = el.textContent.trim().replace(/\s+/g, " ");
    const colonIdx = t.indexOf(":");
    if (colonIdx > 0 && colonIdx < 60) {
      const k = t.slice(0, colonIdx).trim();
      const v = t.slice(colonIdx + 1).trim();
      if (k && v)
        specs[k] = v.slice(0, 200);
    }
  });
  return specs;
}
export {
  $all as $,
  $ as a,
  extractTableSpecs as b,
  cleanPrice as c,
  extractBulletSpecs as d,
  extractStars as e,
  extractReviews as f,
  parseStockStatus as p,
  safeInt as s,
  text as t
};
//# sourceMappingURL=utils-369fade9.js.map
