const CACHE_PREFIX = "shopsense_cache_";
const CACHE_TTL_MS = 24 * 60 * 60 * 1e3;
function normaliseUrl(rawUrl) {
  try {
    const url = new URL(rawUrl);
    const DROP_PARAMS = [
      "ref",
      "ref_",
      "tag",
      "linkCode",
      "camp",
      "creative",
      "ascsubtag",
      "smid",
      "utm_source",
      "utm_medium",
      "utm_campaign",
      "utm_content",
      "utm_term",
      "ei",
      "pf_rd_p",
      "pf_rd_r"
    ];
    DROP_PARAMS.forEach((p) => url.searchParams.delete(p));
    url.hash = "";
    return url.toString();
  } catch {
    return rawUrl;
  }
}
function cacheKey(url) {
  return `${CACHE_PREFIX}${normaliseUrl(url)}`;
}
async function getCached(url) {
  const key = cacheKey(url);
  const result = await chrome.storage.local.get(key);
  const entry = result[key];
  if (!entry)
    return null;
  const age = Date.now() - entry.cachedAt;
  if (age > CACHE_TTL_MS) {
    chrome.storage.local.remove(key);
    return null;
  }
  return { ...entry.data, _cacheAge: age };
}
async function setCached(url, data) {
  const key = cacheKey(url);
  await chrome.storage.local.set({
    [key]: { data, cachedAt: Date.now() }
  });
}
async function clearCached(url) {
  await chrome.storage.local.remove(cacheKey(url));
}
async function clearAllCache() {
  const all = await chrome.storage.local.get(null);
  const keys = Object.keys(all).filter((k) => k.startsWith(CACHE_PREFIX));
  if (keys.length > 0) {
    await chrome.storage.local.remove(keys);
  }
  return keys.length;
}
function formatCacheAge(ageMs) {
  const minutes = Math.floor(ageMs / 6e4);
  if (minutes < 1)
    return "just now";
  if (minutes < 60)
    return `${minutes} minute${minutes > 1 ? "s" : ""} ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24)
    return `${hours} hour${hours > 1 ? "s" : ""} ago`;
  const days = Math.floor(hours / 24);
  return `${days} day${days > 1 ? "s" : ""} ago`;
}
export {
  clearAllCache as a,
  clearCached as c,
  formatCacheAge as f,
  getCached as g,
  setCached as s
};
//# sourceMappingURL=cache-62d667f2.js.map
