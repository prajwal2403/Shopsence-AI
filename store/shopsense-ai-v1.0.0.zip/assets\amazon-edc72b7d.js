import { t as text, $ as $all, c as cleanPrice, e as extractStars, s as safeInt, p as parseStockStatus, a as $, b as extractTableSpecs, d as extractBulletSpecs, f as extractReviews } from "./utils-369fade9.js";
function scrape(sel) {
  var _a, _b, _c;
  const productName = text(sel.productName) || document.title.split(":")[0].trim();
  let price = null;
  const whole = text(sel.priceWhole).replace(/[^0-9]/g, "");
  const frac = text(sel.priceFraction).replace(/[^0-9]/g, "") || "00";
  if (whole) {
    price = parseFloat(`${whole}.${frac}`);
  } else {
    const offscreen = (_a = $all(".a-price .a-offscreen")[0]) == null ? void 0 : _a.textContent;
    price = cleanPrice(offscreen) ?? cleanPrice(text(sel.priceFallback));
  }
  const rating = extractStars(text(sel.rating));
  const reviewCount = safeInt(text(sel.reviewCount));
  const stockStatus = parseStockStatus(text(sel.availability));
  const deliveryEstimate = text(sel.deliveryDate);
  const sellerName = text(sel.sellerName);
  const returnPolicy = text(sel.returnPolicy);
  const imgEl = $(sel.imageUrl);
  const imageUrl = (imgEl == null ? void 0 : imgEl.getAttribute("data-old-hires")) || ((_c = (_b = imgEl == null ? void 0 : imgEl.getAttribute("data-a-dynamic-image")) == null ? void 0 : _b.match(/"(https[^"]+)"/)) == null ? void 0 : _c[1]) || (imgEl == null ? void 0 : imgEl.src) || "";
  const specs = {
    ...extractTableSpecs(sel.techSpecTable),
    ...extractBulletSpecs(sel.detailBullets)
  };
  if (Object.keys(specs).length < 3) {
    $all(sel.bulletPoints).map((el) => el.textContent.trim().replace(/\s+/g, " ")).filter((t) => t.length > 10 && t.length < 300).slice(0, 8).forEach((t, i) => {
      specs[`Feature ${i + 1}`] = t;
    });
  }
  const topReviews = extractReviews(sel, 10);
  return {
    platform: "amazon",
    url: location.href,
    productName,
    price,
    currency: "INR",
    rating,
    reviewCount,
    topReviews,
    specs,
    sellerName,
    returnPolicy,
    deliveryEstimate,
    stockStatus,
    imageUrl
  };
}
export {
  scrape
};
//# sourceMappingURL=amazon-edc72b7d.js.map
